package farmer;
import java.sql.*;
public class dbconnect2
{
private Connection con;
public Statement stmt;
public String getconn()
{
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
con=DriverManager.getConnection("Jdbc:Odbc:ashok");
stmt=con.createStatement();
}
catch(Exception e)
{
System.out.println(e);
}
return" ";
}
}